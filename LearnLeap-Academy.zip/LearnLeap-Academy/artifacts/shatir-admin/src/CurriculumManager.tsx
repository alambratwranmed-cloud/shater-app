import { type FormEvent, useEffect, useMemo, useState } from 'react';
import { Archive, Check, CircleAlert, LoaderCircle, Pencil, Plus, RotateCcw, X } from 'lucide-react';
import { supabase } from './lib/supabase';

type Level = 'curricula' | 'academic_years' | 'stages' | 'grades' | 'tracks' | 'subjects' | 'curriculum_offerings';
type Row = Record<string, any> & { id: string; display_name: string; is_active: boolean };
type Country = { id: string; country_code: string; display_name: string; is_active: boolean };
type System = { id: string; country_id: string; system_code: string | null; display_name: string; is_active: boolean };
type Selection = { country: string; system: string; curriculum: string; year: string; stage: string; grade: string; track: string };
type Props = { countries: Country[]; systems: System[]; onToast: (message: string) => void };

const levelDefs: { id: Level; label: string; table: string; code?: string; required: (selection: Selection) => boolean }[] = [
  { id: 'curricula', label: 'Curricula', table: 'curricula', code: 'curriculum_code', required: (s) => !!s.country && !!s.system },
  { id: 'academic_years', label: 'Academic years', table: 'academic_years', code: 'year_code', required: (s) => !!s.curriculum },
  { id: 'stages', label: 'Stages', table: 'stages', code: 'stage_code', required: (s) => !!s.curriculum && !!s.year },
  { id: 'grades', label: 'Grades', table: 'grades', code: 'grade_code', required: (s) => !!s.curriculum && !!s.year && !!s.stage },
  { id: 'tracks', label: 'Tracks', table: 'tracks', code: 'track_code', required: (s) => !!s.curriculum && !!s.year && !!s.stage && !!s.grade },
  { id: 'subjects', label: 'Subjects', table: 'subjects', code: 'subject_code', required: (s) => !!s.curriculum && !!s.year && !!s.stage && !!s.grade && !!s.track },
  { id: 'curriculum_offerings', label: 'Offerings', table: 'curriculum_offerings', code: 'offering_code', required: (s) => !!s.country && !!s.system && !!s.curriculum && !!s.year && !!s.stage && !!s.grade && !!s.track },
];

const emptySelection: Selection = { country: '', system: '', curriculum: '', year: '', stage: '', grade: '', track: '' };
const scopeFor = (level: Level, s: Selection): Record<string, string> => {
  if (level === 'curricula') return { country_id: s.country, educational_system_id: s.system };
  if (level === 'academic_years') return { curriculum_id: s.curriculum };
  if (level === 'stages') return { curriculum_id: s.curriculum, academic_year_id: s.year };
  if (level === 'grades') return { curriculum_id: s.curriculum, academic_year_id: s.year, stage_id: s.stage };
  if (level === 'tracks') return { curriculum_id: s.curriculum, academic_year_id: s.year, stage_id: s.stage, grade_id: s.grade };
  if (level === 'subjects') return { curriculum_id: s.curriculum, academic_year_id: s.year, stage_id: s.stage, grade_id: s.grade, track_id: s.track };
  return { country_id: s.country, educational_system_id: s.system, curriculum_id: s.curriculum, academic_year_id: s.year, stage_id: s.stage, grade_id: s.grade, track_id: s.track };
};

export function CurriculumManager({ countries, systems, onToast }: Props) {
  const [selection, setSelection] = useState<Selection>(emptySelection);
  const [level, setLevel] = useState<Level>('curricula');
  const [records, setRecords] = useState<Record<Level, Row[]>>({ curricula: [], academic_years: [], stages: [], grades: [], tracks: [], subjects: [], curriculum_offerings: [] });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [modal, setModal] = useState<{ level: Level; row?: Row } | null>(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!supabase) return;
    let active = true;
    const load = async () => {
      setLoading(true); setError('');
      const next = {} as Record<Level, Row[]>;
      for (const def of levelDefs) {
        const valid = def.required(selection);
        if (!valid) { next[def.id] = []; continue; }
        let query: any = supabase!.from(def.table).select('*');
        const scope = scopeFor(def.id, selection);
        for (const [key, value] of Object.entries(scope)) query = query.eq(key, value);
        query = query.order(def.id === 'curricula' || def.id === 'academic_years' || def.id === 'curriculum_offerings' ? 'display_name' : 'sort_order').order('display_name');
        const result = await query;
        if (!active) return;
        if (result.error) { setError(`${def.label}: ${result.error.message}`); next[def.id] = []; }
        else next[def.id] = result.data ?? [];
      }
      if (!active) return;
      setRecords(next); setLoading(false);
    };
    void load();
    return () => { active = false; };
  }, [selection.country, selection.system, selection.curriculum, selection.year, selection.stage, selection.grade, selection.track]);

  const filtered = useMemo(() => records[level].filter((row) => `${row.display_name} ${row[levelDefs.find((x) => x.id === level)?.code ?? ''] ?? ''}`.toLowerCase().includes(search.toLowerCase().trim())), [records, level, search]);
  const relatedSystems = systems.filter((system) => system.country_id === selection.country);

  const updateSelection = (key: keyof Selection, value: string) => {
    const resetMap: Record<keyof Selection, Partial<Selection>> = {
      country: { system: '', curriculum: '', year: '', stage: '', grade: '', track: '' },
      system: { curriculum: '', year: '', stage: '', grade: '', track: '' },
      curriculum: { year: '', stage: '', grade: '', track: '' },
      year: { stage: '', grade: '', track: '' },
      stage: { grade: '', track: '' },
      grade: { track: '' },
      track: {},
    };
    setSelection((old) => ({ ...old, ...resetMap[key], [key]: value }));
  };

  const refresh = async () => {
    if (!supabase) return;
    setLoading(true);
    const next = {} as Record<Level, Row[]>;
    for (const def of levelDefs) {
      if (!def.required(selection)) { next[def.id] = []; continue; }
      let query: any = supabase.from(def.table).select('*');
      for (const [key, value] of Object.entries(scopeFor(def.id, selection))) query = query.eq(key, value);
      query = query.order('display_name');
      const result = await query;
      if (result.error) { setError(`${def.label}: ${result.error.message}`); }
      next[def.id] = result.data ?? [];
    }
    setRecords(next); setLoading(false);
  };

  const submit = async (values: Record<string, string | boolean>, event: FormEvent) => {
    event.preventDefault();
    if (!modal || !supabase) return;
    setBusy(true); setError('');
    const payload: Record<string, unknown> = { ...scopeFor(modal.level, selection), display_name: String(values.display_name ?? '').trim(), is_active: values.is_active };
    const code = levelDefs.find((x) => x.id === modal.level)?.code;
    if (code) payload[code] = String(values[code] ?? '').trim() || null;
    if (modal.level === 'curricula') { payload.tenant_id = null; payload.publication_state = values.publication_state; }
    if (modal.level === 'academic_years') {
      payload.starts_on = values.starts_on || null; payload.ends_on = values.ends_on || null;
    }
    if (['stages', 'grades', 'tracks', 'subjects'].includes(modal.level)) payload.sort_order = Number(values.sort_order || 0);
    if (modal.level === 'curriculum_offerings') { payload.tenant_id = null; payload.publication_state = values.publication_state; }
    const result = modal.row
      ? await supabase.from(levelDefs.find((x) => x.id === modal.level)!.table).update(payload).eq('id', modal.row.id)
      : await supabase.from(levelDefs.find((x) => x.id === modal.level)!.table).insert(payload);
    setBusy(false);
    if (result.error) { setError(result.error.message); return; }
    setModal(null); onToast(`${levelDefs.find((x) => x.id === modal.level)?.label.slice(0, -1) ?? 'Record'} ${modal.row ? 'updated' : 'created'} in Supabase.`); await refresh();
  };

  const setActive = async (row: Row) => {
    if (!supabase) return;
    const { error: updateError } = await supabase.from(levelDefs.find((x) => x.id === level)!.table).update({ is_active: !row.is_active }).eq('id', row.id);
    if (updateError) { setError(updateError.message); return; }
    onToast(`${row.display_name} ${row.is_active ? 'deactivated' : 'reactivated'}.`); await refresh();
  };

  const activeDef = levelDefs.find((x) => x.id === level)!;
  const canWork = activeDef.required(selection);
  return <><div className="eyebrow">Taxonomy / Global curriculum</div><div className="page-heading"><div><h1>Curriculum manager</h1><p>Maintain one parent-linked curriculum tree per selected country and educational system. Every write is checked by Supabase RLS and composite constraints.</p></div></div>
    <div className="curriculum-context">
      <SelectField label="Country" value={selection.country} onChange={(v) => updateSelection('country', v)} placeholder="Select country" options={countries.map((x) => [x.id, `${x.display_name} · ${x.country_code}`])} />
      <SelectField label="Educational system" value={selection.system} onChange={(v) => updateSelection('system', v)} placeholder="Select system" disabled={!selection.country} options={relatedSystems.map((x) => [x.id, x.display_name])} />
      <SelectField label="Curriculum" value={selection.curriculum} onChange={(v) => updateSelection('curriculum', v)} placeholder="Select curriculum" disabled={!selection.system} options={records.curricula.map((x) => [x.id, x.display_name])} />
      <SelectField label="Academic year" value={selection.year} onChange={(v) => updateSelection('year', v)} placeholder="Select year" disabled={!selection.curriculum} options={records.academic_years.map((x) => [x.id, x.display_name])} />
      <SelectField label="Stage" value={selection.stage} onChange={(v) => updateSelection('stage', v)} placeholder="Select stage" disabled={!selection.year} options={records.stages.map((x) => [x.id, x.display_name])} />
      <SelectField label="Grade" value={selection.grade} onChange={(v) => updateSelection('grade', v)} placeholder="Select grade" disabled={!selection.stage} options={records.grades.map((x) => [x.id, x.display_name])} />
      <SelectField label="Track" value={selection.track} onChange={(v) => updateSelection('track', v)} placeholder="Select track" disabled={!selection.grade} options={records.tracks.map((x) => [x.id, x.display_name])} />
    </div>
    <div className="hierarchy-layout">
      <nav className="hierarchy-rail" aria-label="Curriculum hierarchy">{levelDefs.map((def, index) => <button key={def.id} className={`hierarchy-step${level === def.id ? ' selected' : ''}`} onClick={() => { setLevel(def.id); setSearch(''); }}><span className="step-index">{String(index + 1).padStart(2, '0')}</span>{def.label}</button>)}</nav>
      <section className="hierarchy-panel"><div className="hierarchy-panel-head"><div><div className="eyebrow">Selected layer</div><h2>{activeDef.label}</h2><p>{canWork ? `${filtered.length} matching records` : 'Choose all required parent records to see this layer.'}</p></div><button className="button button-primary" disabled={!canWork} onClick={() => setModal({ level })}><Plus />Add {activeDef.label.slice(0, -1)}</button></div>
        {error && <div className="notice" role="alert"><CircleAlert /><div><strong>Database request failed.</strong> {error}<br /><button className="button button-quiet" onClick={() => void refresh()}>Retry scoped reads</button></div></div>}
        {!canWork ? <div className="curriculum-status">This layer is locked until its parent selections are made. For example, subjects need a curriculum, year, stage, grade, and track.</div> : loading ? <div className="hierarchy-list" aria-label="Loading hierarchy"><div className="skeleton-block" /><div className="skeleton-block" /></div> : <div className="hierarchy-list">{filtered.length === 0 ? <div className="empty-state"><div className="empty-icon"><CircleAlert /></div><h2>No {activeDef.label.toLowerCase()} found</h2><p>This selected parent currently has no matching database records. Add the first one at this layer.</p><button className="button button-secondary" onClick={() => setModal({ level })}><Plus />Add first record</button></div> : <>{filtered.map((row) => <div className="hierarchy-row" key={row.id}><div className="hierarchy-row-main"><div className="hierarchy-row-name">{row.display_name}</div><div className="hierarchy-row-meta">{activeDef.code && row[activeDef.code] ? row[activeDef.code] : activeDef.id === 'academic_years' && row.starts_on ? `${row.starts_on} — ${row.ends_on ?? 'open'}` : `Sort order ${row.sort_order ?? 0}`}{row.publication_state ? ` · ${row.publication_state.replaceAll('_', ' ')}` : ''}</div></div><span className={`status-pill ${row.is_active ? 'status-active' : 'status-inactive'}`}>{row.is_active ? 'Active' : 'Inactive'}</span><div className="action-group"><button className="icon-button" onClick={() => setModal({ level, row })} title={`Edit ${row.display_name}`} aria-label={`Edit ${row.display_name}`}><Pencil /></button><button className={`icon-button${row.is_active ? ' deactivate' : ''}`} onClick={() => void setActive(row)} title={row.is_active ? 'Deactivate' : 'Reactivate'} aria-label={`${row.is_active ? 'Deactivate' : 'Reactivate'} ${row.display_name}`}>{row.is_active ? <Archive /> : <RotateCcw />}</button></div></div>)}</>}</div>}
      </section>
    </div>
    {modal && <HierarchyForm level={modal.level} row={modal.row} countryName={countries.find((x) => x.id === selection.country)?.display_name ?? ''} onClose={() => setModal(null)} onSubmit={submit} busy={busy} error={error} />}
  </>;
}

function SelectField({ label, value, onChange, options, placeholder, disabled = false }: { label: string; value: string; onChange: (value: string) => void; options: [string, string][]; placeholder: string; disabled?: boolean }) {
  return <div className="field"><label>{label}</label><select className="field-select" value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)}><option value="">{placeholder}</option>{options.map(([id, label]) => <option value={id} key={id}>{label}</option>)}</select></div>;
}

function HierarchyForm({ level, row, countryName, onClose, onSubmit, busy, error }: { level: Level; row?: Row; countryName: string; onClose: () => void; onSubmit: (values: Record<string, string | boolean>, event: FormEvent) => void; busy: boolean; error: string }) {
  const def = levelDefs.find((x) => x.id === level)!;
  const [values, setValues] = useState<Record<string, string | boolean>>(() => ({
    display_name: row?.display_name ?? '', is_active: row?.is_active ?? true,
    ...(def.code ? { [def.code]: row?.[def.code] ?? '' } : {}),
    ...(level === 'academic_years' ? { starts_on: row?.starts_on ?? '', ends_on: row?.ends_on ?? '' } : {}),
    ...(level === 'curricula' || level === 'curriculum_offerings' ? { publication_state: row?.publication_state ?? 'draft' } : {}),
    ...(['stages', 'grades', 'tracks', 'subjects'].includes(level) ? { sort_order: String(row?.sort_order ?? 0) } : {}),
  }));
  const set = (key: string, value: string | boolean) => setValues((current) => ({ ...current, [key]: value }));
  return <div className="form-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><form className="form-panel" onSubmit={(event) => onSubmit(values, event)}><div className="form-head"><div><div className="eyebrow">{row ? 'Edit taxonomy record' : 'New taxonomy record'}</div><h2>{row ? 'Edit' : 'Add'} {def.label.slice(0, -1)}</h2><p>Writes use your authenticated platform session. Parent IDs are fixed to the current selection.</p></div><button type="button" className="close-button" onClick={onClose} aria-label="Close"><X /></button></div><div className="form-body">{error && <div className="form-validation-summary" role="alert">{error}</div>}{(level === 'curricula' || level === 'curriculum_offerings') && <div className="curriculum-status">Global record · {countryName || 'Selected country'} · Parent relationships remain database constrained.</div>}<div className="field"><label>Display name <span className="field-hint">Required</span></label><input className="field-input" value={String(values.display_name)} onChange={(e) => set('display_name', e.target.value)} required maxLength={160} autoFocus /></div>{def.code && <div className="field"><label>{def.code.replace('_', ' ')} {level === 'academic_years' && <span className="field-hint">Required</span>}</label><input className="field-input" value={String(values[def.code] ?? '')} onChange={(e) => set(def.code!, e.target.value)} required={level === 'academic_years'} maxLength={80} /></div>}{level === 'academic_years' && <><div className="field"><label>Starts on <span className="field-hint">Optional</span></label><input className="field-input" type="date" value={String(values.starts_on)} onChange={(e) => set('starts_on', e.target.value)} /></div><div className="field"><label>Ends on <span className="field-hint">Optional</span></label><input className="field-input" type="date" value={String(values.ends_on)} onChange={(e) => set('ends_on', e.target.value)} /></div></>}{['stages', 'grades', 'tracks', 'subjects'].includes(level) && <div className="field"><label>Sort order</label><input className="field-input" type="number" step="1" value={String(values.sort_order)} onChange={(e) => set('sort_order', e.target.value)} /></div>}{(level === 'curricula' || level === 'curriculum_offerings') && <div className="field"><label>Publication state</label><select className="field-select" value={String(values.publication_state)} onChange={(e) => set('publication_state', e.target.value)}>{['draft', 'under_review', 'approved', 'published', 'archived'].map((state) => <option key={state} value={state}>{state.replaceAll('_', ' ')}</option>)}</select></div>}<label style={{ display: 'flex', gap: 9, alignItems: 'center', color: '#485a57', fontSize: 12 }}><input type="checkbox" checked={Boolean(values.is_active)} onChange={(e) => set('is_active', e.target.checked)} />Active</label></div><div className="form-footer"><button type="button" className="button button-secondary" onClick={onClose}>Cancel</button><button type="submit" className="button button-primary" disabled={busy}>{busy ? <LoaderCircle /> : <Check />}{busy ? 'Saving…' : row ? 'Save changes' : 'Create record'}</button></div></form></div>;
}