import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { Link, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import {
  ArrowRight, BookOpen, Check, ChevronRight, CircleAlert, Globe2, GraduationCap,
  Layers3, LogOut, Map, Pencil, Plus, Search, ShieldCheck, X, Archive, RotateCcw,
  LoaderCircle, RefreshCw, LockKeyhole, Database,
} from 'lucide-react';
import {
  supabase,
  supabaseConfigurationError,
  supabaseConfigured,
} from './lib/supabase';
import { CurriculumManager } from './CurriculumManager';
import type { User } from '@supabase/supabase-js';

type Country = { id: string; country_code: string; display_name: string; is_active: boolean };
type Region = { id: string; country_id: string; parent_region_id: string | null; region_code: string | null; display_name: string; region_type: string | null; is_active: boolean };
type EducationalSystem = { id: string; country_id: string; region_id: string | null; system_code: string | null; display_name: string; is_active: boolean };
type RecordRow = Record<string, any> & { id: string; display_name: string; is_active: boolean };
type Kind = 'country' | 'region' | 'system';
type CatalogItem = Country | Region | EducationalSystem;
type Draft = Record<string, string | boolean | null>;
type Level = 'curricula' | 'academic_years' | 'stages' | 'grades' | 'tracks' | 'subjects' | 'curriculum_offerings';
type PermissionState = 'checking' | 'allowed' | 'denied' | 'profile-missing' | 'error';

const kindInfo: Record<Kind, { title: string; singular: string; description: string; icon: typeof Globe2; path: string; table: string }> = {
  country: { title: 'Countries', singular: 'country', description: 'The global country catalog and foundation for education geography.', icon: Globe2, path: '/countries', table: 'countries' },
  region: { title: 'Regions', singular: 'region', description: 'Subnational areas organized within a country and parent region.', icon: Map, path: '/regions', table: 'regions' },
  system: { title: 'Educational systems', singular: 'educational system', description: 'National and regional education frameworks linked to geography.', icon: BookOpen, path: '/education-systems', table: 'educational_systems' },
};

const levelInfo: Record<Level, { title: string; table: string; singular: string; description: string; code?: string }> = {
  curricula: { title: 'Curricula', table: 'curricula', singular: 'curriculum', description: 'Country and educational-system frameworks.', code: 'curriculum_code' },
  academic_years: { title: 'Academic years', table: 'academic_years', singular: 'academic year', description: 'Year ranges and labels within a curriculum.', code: 'year_code' },
  stages: { title: 'Stages', table: 'stages', singular: 'stage', description: 'Learning stages within an academic year.', code: 'stage_code' },
  grades: { title: 'Grades', table: 'grades', singular: 'grade', description: 'Grade levels within a stage.', code: 'grade_code' },
  tracks: { title: 'Tracks', table: 'tracks', singular: 'track', description: 'Learning pathways within a grade.', code: 'track_code' },
  subjects: { title: 'Subjects', table: 'subjects', singular: 'subject', description: 'Subject taxonomy within a track.', code: 'subject_code' },
  curriculum_offerings: { title: 'Curriculum offerings', table: 'curriculum_offerings', singular: 'offering', description: 'A publishable offering scoped to a grade and track.', code: 'offering_code' },
};

const levels: Level[] = ['curricula', 'academic_years', 'stages', 'grades', 'tracks', 'subjects', 'curriculum_offerings'];
const publicationStates = ['draft', 'under_review', 'approved', 'published', 'archived'];

function AdminWorkspace() {
  const [location] = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [sessionReady, setSessionReady] = useState(false);
  const [permission, setPermission] = useState<PermissionState>('checking');
  const [permissionAttempt, setPermissionAttempt] = useState(0);
  const [permissionError, setPermissionError] = useState('');
  const [profileName, setProfileName] = useState('');
  const [authError, setAuthError] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [catalogs, setCatalogs] = useState<{ countries: Country[]; regions: Region[]; systems: EducationalSystem[] }>({ countries: [], regions: [], systems: [] });
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [catalogError, setCatalogError] = useState('');
  const [modal, setModal] = useState<{ kind: Kind; item?: CatalogItem } | null>(null);
  const [confirm, setConfirm] = useState<{ kind: Kind; item: CatalogItem } | null>(null);
  const [toast, setToast] = useState('');

  useEffect(() => {
    if (!supabase) { setSessionReady(true); return; }
    let active = true;
    supabase.auth.getSession().then(({ data, error }) => {
      if (!active) return;
      if (error) setAuthError(error.message);
      setUser(data.session?.user ?? null);
      setSessionReady(true);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setPermission('checking');
      setProfileName('');
    });
    return () => { active = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!user || !supabase) { setPermission('checking'); return; }
    let active = true;
    async function verifyPlatformPermission() {
      setPermission('checking'); setPermissionError('');
      const profile = await supabase!.from('users').select('id, display_name, status').eq('id', user!.id).maybeSingle();
      if (!active) return;
      if (profile.error) { setPermission('error'); setPermissionError(profile.error.message); return; }
      if (!profile.data || profile.data.status !== 'active') { setPermission('profile-missing'); return; }
      setProfileName(profile.data.display_name);
      const assignments = await supabase!.from('admins').select('role_id').eq('user_id', user!.id).is('tenant_id', null).eq('is_active', true);
      if (!active) return;
      if (assignments.error) { setPermission('error'); setPermissionError(assignments.error.message); return; }
      const roleIds = (assignments.data ?? []).map((row) => row.role_id);
      if (!roleIds.length) { setPermission('denied'); return; }
      const roles = await supabase!.from('roles').select('id').in('id', roleIds).eq('role_scope', 'platform').is('tenant_id', null).eq('is_active', true);
      if (!active) return;
      if (roles.error) { setPermission('error'); setPermissionError(roles.error.message); return; }
      const validRoleIds = (roles.data ?? []).map((row) => row.id);
      if (!validRoleIds.length) { setPermission('denied'); return; }
      const grants = await supabase!.from('role_permissions').select('permission_id').in('role_id', validRoleIds);
      if (!active) return;
      if (grants.error) { setPermission('error'); setPermissionError(grants.error.message); return; }
      const permissionIds = [...new Set((grants.data ?? []).map((row) => row.permission_id))];
      if (!permissionIds.length) { setPermission('denied'); return; }
      const permissions = await supabase!.from('permissions').select('id, permission_key').in('id', permissionIds).eq('permission_key', 'platform.manage');
      if (!active) return;
      if (permissions.error) { setPermission('error'); setPermissionError(permissions.error.message); return; }
      setPermission(permissions.data?.length ? 'allowed' : 'denied');
    }
    void verifyPlatformPermission();
    return () => { active = false; };
  }, [user, permissionAttempt]);

  useEffect(() => {
    if (permission !== 'allowed' || !supabase) return;
    let active = true;
    async function loadCatalogs() {
      setCatalogLoading(true); setCatalogError('');
      const [countries, regions, systems] = await Promise.all([
        supabase!.from('countries').select('id,country_code,display_name,is_active').order('display_name'),
        supabase!.from('regions').select('id,country_id,parent_region_id,region_code,display_name,region_type,is_active').order('display_name'),
        supabase!.from('educational_systems').select('id,country_id,region_id,system_code,display_name,is_active').order('display_name'),
      ]);
      if (!active) return;
      const error = countries.error ?? regions.error ?? systems.error;
      if (error) setCatalogError(error.message);
      else setCatalogs({ countries: countries.data ?? [], regions: regions.data ?? [], systems: systems.data ?? [] });
      setCatalogLoading(false);
    }
    void loadCatalogs();
    return () => { active = false; };
  }, [permission]);

  const showToast = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 3200); };
  const reloadCatalogs = async () => {
    if (!supabase) return;
    const [countries, regions, systems] = await Promise.all([
      supabase.from('countries').select('id,country_code,display_name,is_active').order('display_name'),
      supabase.from('regions').select('id,country_id,parent_region_id,region_code,display_name,region_type,is_active').order('display_name'),
      supabase.from('educational_systems').select('id,country_id,region_id,system_code,display_name,is_active').order('display_name'),
    ]);
    const error = countries.error ?? regions.error ?? systems.error;
    if (error) setCatalogError(error.message);
    else { setCatalogs({ countries: countries.data ?? [], regions: regions.data ?? [], systems: systems.data ?? [] }); setCatalogError(''); }
  };
  const saveCatalogItem = async (kind: Kind, draft: Draft, item?: CatalogItem) => {
    if (!supabase) return;
    const data: Record<string, unknown> = { display_name: String(draft.display_name).trim() };
    if (kind === 'country') data.country_code = String(draft.country_code).trim().toUpperCase();
    if (kind === 'region') Object.assign(data, { country_id: draft.country_id, parent_region_id: draft.parent_region_id || null, region_code: String(draft.region_code || '').trim() || null, region_type: String(draft.region_type || '').trim() || null });
    if (kind === 'system') Object.assign(data, { country_id: draft.country_id, region_id: draft.region_id || null, system_code: String(draft.system_code || '').trim() || null });
    const result = item
      ? await supabase.from(kindInfo[kind].table).update(data).eq('id', item.id)
      : await supabase.from(kindInfo[kind].table).insert(data);
    if (result.error) { showToast(`Could not save: ${result.error.message}`); return; }
    setModal(null); showToast(`${kindInfo[kind].singular} ${item ? 'updated' : 'added'} in Supabase.`); await reloadCatalogs();
  };
  const toggleCatalogItem = async () => {
    if (!confirm || !supabase) return;
    const { kind, item } = confirm;
    const { error } = await supabase.from(kindInfo[kind].table).update({ is_active: !item.is_active }).eq('id', item.id);
    if (error) showToast(`Could not update status: ${error.message}`);
    else { showToast(`${kindInfo[kind].singular} ${item.is_active ? 'deactivated' : 'reactivated'}.`); await reloadCatalogs(); }
    setConfirm(null);
  };

  if (!supabaseConfigured) return <SetupState error={supabaseConfigurationError} />;
  if (!sessionReady) return <LoadingScreen label="Restoring your secure session" />;
  if (!user) return <SignIn onSubmit={async (email, password) => {
    if (!supabase) return;
    setAuthBusy(true); setAuthError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setAuthError(error.message);
    setAuthBusy(false);
  }} busy={authBusy} error={authError} />;
  if (permission === 'checking') return <LoadingScreen label="Verifying your platform permissions" />;
  if (permission !== 'allowed') return <AccessState state={permission} error={permissionError} onSignOut={async () => { await supabase?.auth.signOut(); }} onRetry={() => setPermissionAttempt((attempt) => attempt + 1)} />;

  const currentKind: Kind | null = location === '/countries' ? 'country' : location === '/regions' ? 'region' : location === '/education-systems' ? 'system' : null;
  const counts = catalogs;
  return <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark">ش</div><div><div className="brand-name">Shatir Admin</div><span className="brand-caption">PLATFORM CATALOG</span></div></div>
        <div className="nav-label">Platform</div>
        <nav className="nav-list" aria-label="Platform navigation">
          <NavItem href="/" active={location === '/'} icon={<Layers3 />} label="Overview" />
          <NavItem href="/countries" active={location === '/countries'} icon={<Globe2 />} label="Countries" />
          <NavItem href="/regions" active={location === '/regions'} icon={<Map />} label="Regions" />
          <NavItem href="/education-systems" active={location === '/education-systems'} icon={<BookOpen />} label="Educational systems" />
          <NavItem href="/curricula" active={location === '/curricula'} icon={<GraduationCap />} label="Curricula" />
        </nav>
        <div className="sidebar-bottom"><div className="sidebar-rule" /><div className="platform-chip"><div className="platform-avatar">SA</div><div><strong style={{ display: 'block', fontSize: 11 }}>Platform access</strong><span style={{ color: '#a9bbb2', fontSize: 10 }}>{profileName || user.email}</span></div></div></div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="crumbs"><span>Shatir</span><ChevronRight size={13} /><strong>{location === '/curricula' ? 'Curriculum manager' : currentKind ? kindInfo[currentKind].title : 'Overview'}</strong></div>
          <div className="topbar-user"><ShieldCheck /><span>Platform manager</span><button className="signout-button" onClick={() => void supabase?.auth.signOut()} title="Sign out"><LogOut size={14} /></button></div>
        </header>
        <div className="content">
          {catalogError && <ErrorNotice message={catalogError} onRetry={() => void reloadCatalogs()} />}
          {catalogLoading ? <PageSkeleton /> : <Switch>
            <Route path="/"><Overview countries={counts.countries} regions={counts.regions} systems={counts.systems} /></Route>
            <Route path="/countries"><CatalogPage kind="country" items={counts.countries} countries={counts.countries} regions={counts.regions} systems={counts.systems} onCreate={() => setModal({ kind: 'country' })} onEdit={(item) => setModal({ kind: 'country', item })} onToggle={(item) => setConfirm({ kind: 'country', item })} /></Route>
            <Route path="/regions"><CatalogPage kind="region" items={counts.regions} countries={counts.countries} regions={counts.regions} systems={counts.systems} onCreate={() => setModal({ kind: 'region' })} onEdit={(item) => setModal({ kind: 'region', item })} onToggle={(item) => setConfirm({ kind: 'region', item })} /></Route>
            <Route path="/education-systems"><CatalogPage kind="system" items={counts.systems} countries={counts.countries} regions={counts.regions} systems={counts.systems} onCreate={() => setModal({ kind: 'system' })} onEdit={(item) => setModal({ kind: 'system', item })} onToggle={(item) => setConfirm({ kind: 'system', item })} /></Route>
            <Route path="/curricula"><CurriculumManager countries={counts.countries} systems={counts.systems} onToast={showToast} /></Route>
            <Route><NotFound /></Route>
          </Switch>}
        </div>
      </main>
      {modal && <CatalogForm kind={modal.kind} item={modal.item} countries={counts.countries} regions={counts.regions} onClose={() => setModal(null)} onSave={(draft) => void saveCatalogItem(modal.kind, draft, modal.item)} />}
      {confirm && <ConfirmDialog kind={confirm.kind} item={confirm.item} dependencies={downstream(confirm.kind, confirm.item.id, counts.regions, counts.systems)} onCancel={() => setConfirm(null)} onConfirm={() => void toggleCatalogItem()} />}
      {toast && <div className="toast-stack"><div className="toast" role="status"><Check />{toast}</div></div>}
    </div>;
}

function App() {
  return <WouterRouter><AdminWorkspace /></WouterRouter>;
}

function NavItem({ href, active, icon, label }: { href: string; active: boolean; icon: ReactNode; label: string }) {
  return <Link href={href} className={`nav-link${active ? ' active' : ''}`} data-testid={`link-${label.toLowerCase().replaceAll(' ', '-')}`}>{icon}<span>{label}</span></Link>;
}

function SetupState({ error }: { error: string }) {
  return <div className="auth-shell"><aside className="auth-aside"><div className="auth-brand"><div className="brand-mark">ش</div><div><div className="brand-name">Shatir Admin</div><span className="brand-caption">PLATFORM CATALOG</span></div></div><div><h1>One clear map of education, everywhere.</h1><p>Maintain the shared taxonomy that keeps a global learning platform coherent.</p></div><div className="auth-aside-foot">Secure platform workspace</div></aside><main className="auth-main"><section className="auth-card"><div className="empty-icon"><Database /></div><h2>Supabase setup required</h2><p>{error} Management data is never simulated.</p><div className="curriculum-status"><strong>Required configuration</strong><br />VITE_SUPABASE_URL (or SUPABASE_URL)<br />VITE_SUPABASE_ANON_KEY (or SUPABASE_KEY)</div><p>Use the Supabase project API URL and public anon key. Do not use a service-role key in the browser.</p></section></main></div>;
}

function SignIn({ onSubmit, busy, error }: { onSubmit: (email: string, password: string) => Promise<void>; busy: boolean; error: string }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const submit = (event: FormEvent) => { event.preventDefault(); void onSubmit(email.trim(), password); };
  return <div className="auth-shell"><aside className="auth-aside"><div className="auth-brand"><div className="brand-mark">ش</div><div><div className="brand-name">Shatir Admin</div><span className="brand-caption">PLATFORM CATALOG</span></div></div><div><h1>One clear map of education, everywhere.</h1><p>Platform catalog access is reserved for authorized Shatir administrators. Sign in with your issued account.</p></div><div className="auth-aside-foot">Authenticated access · Supabase</div></aside><main className="auth-main"><form className="auth-card" onSubmit={submit}><div className="eyebrow">Administrator sign-in</div><h2>Welcome back</h2><p>Use your email and password to continue to the global catalog workspace.</p>{error && <div className="auth-error" role="alert">{error}</div>}<div className="field"><label htmlFor="email">Email address</label><input id="email" className="field-input" type="email" autoComplete="username" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@organization.org" data-testid="input-email" /></div><div className="field"><label htmlFor="password">Password</label><input id="password" className="field-input" type="password" autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} data-testid="input-password" /></div><button className="button button-primary" type="submit" disabled={busy} style={{ width: '100%', marginTop: 5 }} data-testid="button-sign-in">{busy ? <LoaderCircle className="spin" /> : <LockKeyhole />}{busy ? 'Signing in…' : 'Sign in securely'}</button><p style={{ margin: '17px 0 0', fontSize: 10 }}>Accounts are provisioned by platform administrators. Public sign-up is disabled.</p></form></main></div>;
}

function LoadingScreen({ label }: { label: string }) {
  return <div className="auth-shell"><aside className="auth-aside"><div className="auth-brand"><div className="brand-mark">ش</div><div><div className="brand-name">Shatir Admin</div><span className="brand-caption">PLATFORM CATALOG</span></div></div><div><h1>Global learning, clearly organized.</h1><p>Preparing your authenticated workspace.</p></div><div className="auth-aside-foot">Secure platform workspace</div></aside><main className="auth-main"><section className="auth-card" aria-label={label}><div className="skeleton-line" style={{ width: 90 }} /><div className="skeleton-line" style={{ width: '72%', height: 26, marginTop: 18 }} /><div className="skeleton-block" /><div className="skeleton-line" style={{ width: '100%', height: 40, marginTop: 14 }} /><div className="skeleton-line" style={{ width: '100%', height: 40, marginTop: 10 }} /></section></main></div>;
}

function AccessState({ state, error, onSignOut, onRetry }: { state: PermissionState; error: string; onSignOut: () => void; onRetry: () => void }) {
  const title = state === 'profile-missing' ? 'Administrator profile unavailable' : state === 'error' ? 'Permission check could not complete' : 'Platform access not assigned';
  const message = state === 'profile-missing' ? 'This authenticated account has no active profile in the users table. Ask a platform administrator to review the account.' : state === 'error' ? `The live account and role permission checks failed. Verify RLS access and database setup. ${error}` : 'Your account does not currently have an active platform role granting platform.manage. Catalog controls remain hidden.';
  return <div className="auth-shell"><aside className="auth-aside"><div className="auth-brand"><div className="brand-mark">ش</div><div><div className="brand-name">Shatir Admin</div><span className="brand-caption">PLATFORM CATALOG</span></div></div><div><h1>Permission before management.</h1><p>Shatir checks the active account role against the platform permission catalog.</p></div><div className="auth-aside-foot">Role-verified access</div></aside><main className="auth-main"><section className="auth-card"><div className="empty-icon" style={{ color: '#a26051', background: '#f4e8df' }}><CircleAlert /></div><h2>{title}</h2><p>{message}</p>{state === 'error' && <button className="button button-secondary" onClick={onRetry}><RefreshCw />Retry verification</button>}<button className="button button-quiet" onClick={onSignOut}><LogOut />Sign out</button></section></main></div>;
}

function ErrorNotice({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <div className="notice" role="alert"><CircleAlert /><div><strong>Live data could not be loaded.</strong> {message}<br /><button className="button button-quiet" onClick={onRetry}>Retry database read</button></div></div>;
}

function PageSkeleton() {
  return <><div className="skeleton-line" style={{ width: 100, marginBottom: 16 }} /><div className="skeleton-line" style={{ width: '45%', height: 34, marginBottom: 24 }} /><div className="skeleton-block" /><div className="skeleton-block" /></>;
}

function Overview({ countries, regions, systems }: { countries: Country[]; regions: Region[]; systems: EducationalSystem[] }) {
  const entries = [
    { kind: 'country' as Kind, count: countries.length, active: countries.filter((x) => x.is_active).length, description: 'Country identities anchor every geography record.' },
    { kind: 'region' as Kind, count: regions.length, active: regions.filter((x) => x.is_active).length, description: 'Nested administrative areas, anchored to their country.' },
    { kind: 'system' as Kind, count: systems.length, active: systems.filter((x) => x.is_active).length, description: 'Education frameworks connected to a country or region.' },
  ];
  return <><div className="eyebrow">Global education · Catalog control</div><div className="overview-intro"><div><h1>One clear map of education, everywhere.</h1><p>Maintain the global geography, educational systems, and country-specific curriculum taxonomy that keep Shatir's learning platform coherent.</p></div><div className="overview-count"><b>{countries.length + regions.length + systems.length}</b><span>catalog records</span></div></div><div className="catalog-list">{entries.map(({ kind, count, active }, index) => <Link key={kind} href={kindInfo[kind].path} className="catalog-row"><div className="catalog-index">0{index + 1}</div><div><div className="catalog-title">{kindInfo[kind].title}</div><div className="catalog-description">{kindInfo[kind].description}</div></div><div className="catalog-count"><b>{count}</b><span>{active} active</span></div><ArrowRight className="row-arrow" /></Link>)}<Link href="/curricula" className="catalog-row"><div className="catalog-index">04</div><div><div className="catalog-title">Curriculum hierarchy</div><div className="catalog-description">Academic years through offerings, with parent-scoped selectors.</div></div><div className="catalog-count"><GraduationCap size={22} color="#496f62" /></div><ArrowRight className="row-arrow" /></Link></div><div className="stat-strip">{entries.map(({ kind, count }) => <div className="stat" key={kind}><div className="stat-label">{kindInfo[kind].title}</div><div className="stat-value">{count} <span style={{ color: '#8a938d', fontSize: 12, fontWeight: 400 }}>in catalog</span></div></div>)}</div></>;
}

function CatalogPage({ kind, items, countries, regions, systems, onCreate, onEdit, onToggle }: {
  kind: Kind; items: CatalogItem[]; countries: Country[]; regions: Region[]; systems: EducationalSystem[];
  onCreate: () => void; onEdit: (item: CatalogItem) => void; onToggle: (item: CatalogItem) => void;
}) {
  const [query, setQuery] = useState(''); const [status, setStatus] = useState('all'); const [countryFilter, setCountryFilter] = useState('all');
  const info = kindInfo[kind];
  const filtered = useMemo(() => items.filter((item) => {
    const matchStatus = status === 'all' || (status === 'active' ? item.is_active : !item.is_active);
    const text = kind === 'country' ? `${(item as Country).display_name} ${(item as Country).country_code}` : kind === 'region' ? `${(item as Region).display_name} ${(item as Region).region_code ?? ''} ${(item as Region).region_type ?? ''}` : `${(item as EducationalSystem).display_name} ${(item as EducationalSystem).system_code ?? ''}`;
    const matchCountry = countryFilter === 'all' || kind === 'country' || (item as Region | EducationalSystem).country_id === countryFilter;
    return matchStatus && matchCountry && text.toLowerCase().includes(query.toLowerCase().trim());
  }), [items, query, status, countryFilter, kind]);
  const hasNoParents = kind !== 'country' && countries.length === 0;
  const Icon = info.icon;
  return <><div className="eyebrow">Catalog / {info.title}</div><div className="page-heading"><div><h1>{info.title}</h1><p>{info.description} Changes are written to the global Supabase catalog.</p></div><button className="button button-primary" onClick={onCreate} disabled={hasNoParents}><Plus />Add {info.singular}</button></div><div className="page-toolbar"><div className="search-wrap"><Search /><input className="search-input" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Search ${info.title.toLowerCase()}…`} aria-label={`Search ${info.title}`} /></div><select className="filter-select" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status"><option value="all">All statuses</option><option value="active">Active</option><option value="inactive">Inactive</option></select>{kind !== 'country' && <select className="filter-select" value={countryFilter} onChange={(e) => setCountryFilter(e.target.value)} aria-label="Filter by country"><option value="all">All countries</option>{countries.map((country) => <option key={country.id} value={country.id}>{country.display_name}</option>)}</select>}<div className="toolbar-spacer" /><span className="result-count">{filtered.length} records</span></div><div className="table-frame">{filtered.length === 0 ? <div className="empty-state"><div className="empty-icon"><Icon /></div><h2>{items.length ? 'No matching records' : `No ${info.title.toLowerCase()} yet`}</h2><p>{hasNoParents ? 'Add a country first. This catalog needs a parent country.' : items.length ? 'Try adjusting your search or filters.' : `Your live ${info.title.toLowerCase()} catalog is empty. Add the first record when ready.`}</p>{items.length === 0 && !hasNoParents && <button className="button button-secondary" onClick={onCreate}><Plus />Add first {info.singular}</button>}</div> : <div className="table-scroll"><table className="data-table"><thead><tr>{kind === 'country' ? <><th>Country</th><th>Code</th><th>Regions</th><th>Education systems</th></> : kind === 'region' ? <><th>Region</th><th>Country</th><th>Parent region</th><th>Type</th></> : <><th>Educational system</th><th>Country</th><th>Region</th><th>Code</th></>}<th>Status</th><th /></tr></thead><tbody>{filtered.map((item) => <CatalogTableRow key={item.id} item={item} kind={kind} countries={countries} regions={regions} systems={systems} onEdit={onEdit} onToggle={onToggle} />)}</tbody></table></div>}</div>{hasNoParents && <div className="field-note" style={{ marginTop: 13 }}>Create a country before adding {info.title.toLowerCase()}.</div>}</>;
}

function CatalogTableRow({ item, kind, countries, regions, systems, onEdit, onToggle }: { item: CatalogItem; kind: Kind; countries: Country[]; regions: Region[]; systems: EducationalSystem[]; onEdit: (item: CatalogItem) => void; onToggle: (item: CatalogItem) => void }) {
  const countryName = (id: string) => countries.find((x) => x.id === id)?.display_name ?? 'Unknown country';
  const regionName = (id: string | null) => id ? regions.find((x) => x.id === id)?.display_name ?? 'Unknown region' : '—';
  return <tr><>{kind === 'country' && <><td><div className="cell-title">{(item as Country).display_name}</div></td><td><span className="code-pill">{(item as Country).country_code}</span></td><td>{regions.filter((x) => x.country_id === item.id).length}</td><td>{systems.filter((x) => x.country_id === item.id).length}</td></>}{kind === 'region' && <><td><div className="cell-title">{(item as Region).display_name}</div><div className="cell-secondary">{(item as Region).region_code || 'No region code'}</div></td><td>{countryName((item as Region).country_id)}</td><td>{regionName((item as Region).parent_region_id)}</td><td>{(item as Region).region_type || '—'}</td></>}{kind === 'system' && <><td><div className="cell-title">{(item as EducationalSystem).display_name}</div></td><td>{countryName((item as EducationalSystem).country_id)}</td><td>{regionName((item as EducationalSystem).region_id)}</td><td>{(item as EducationalSystem).system_code || '—'}</td></>}</><td><span className={`status-pill ${item.is_active ? 'status-active' : 'status-inactive'}`}>{item.is_active ? 'Active' : 'Inactive'}</span></td><td className="actions-cell"><div className="action-group"><button className="icon-button" onClick={() => onEdit(item)} title="Edit"><Pencil /></button><button className={`icon-button${item.is_active ? ' deactivate' : ''}`} onClick={() => onToggle(item)} title={item.is_active ? 'Deactivate' : 'Reactivate'}>{item.is_active ? <Archive /> : <RotateCcw />}</button></div></td></tr>;
}

function CatalogForm({ kind, item, countries, regions, onClose, onSave }: { kind: Kind; item?: CatalogItem; countries: Country[]; regions: Region[]; onClose: () => void; onSave: (draft: Draft) => void }) {
  const initialCountry = item && 'country_id' in item ? item.country_id : countries[0]?.id ?? '';
  const initialValues = (): Draft => {
    if (kind === 'country') {
      const country = item as Country | undefined;
      return {
        display_name: country?.display_name ?? '',
        country_code: country?.country_code ?? '',
      };
    }
    if (kind === 'region') {
      const region = item as Region | undefined;
      return {
        display_name: region?.display_name ?? '',
        country_id: region?.country_id ?? initialCountry,
        parent_region_id: region?.parent_region_id ?? '',
        region_code: region?.region_code ?? '',
        region_type: region?.region_type ?? '',
      };
    }
    const system = item as EducationalSystem | undefined;
    return {
      display_name: system?.display_name ?? '',
      country_id: system?.country_id ?? initialCountry,
      region_id: system?.region_id ?? '',
      system_code: system?.system_code ?? '',
    };
  };
  const [values, setValues] = useState<Draft>(initialValues);
  const [error, setError] = useState('');
  const set = (key: string, value: string) => setValues((old) => ({ ...old, [key]: value, ...(key === 'country_id' ? { parent_region_id: '', region_id: '' } : {}) }));
  const countryId = String(values.country_id ?? '');
  const parentOptions = regions.filter((r) => r.country_id === countryId && r.is_active && r.id !== item?.id);
  const submit = (event: FormEvent) => { event.preventDefault(); const name = String(values.display_name ?? '').trim(); if (!name) { setError('A display name is required.'); return; } if (kind === 'country' && !/^[A-Z]{2}$/.test(String(values.country_code ?? '').trim().toUpperCase())) { setError('Use a two-letter country code.'); return; } if (kind !== 'country' && !countryId) { setError('Choose a parent country.'); return; } setError(''); onSave({ ...values, display_name: name, country_code: String(values.country_code ?? '').toUpperCase() }); };
  const countryField = kind !== 'country' && <div className="field"><label>Parent country</label><select className="field-select" value={countryId} onChange={(e) => set('country_id', e.target.value)} required><option value="">Choose country</option>{countries.map((c) => <option key={c.id} value={c.id}>{c.display_name} ({c.country_code}){!c.is_active ? ' · inactive' : ''}</option>)}</select></div>;
  return <div className="form-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><form className="form-panel" onSubmit={submit}><div className="form-head"><div><div className="eyebrow">{item ? 'Update global catalog' : 'New global catalog entry'}</div><h2>{item ? 'Edit' : 'Add'} {kindInfo[kind].singular}</h2><p>Saved to the authenticated global catalog.</p></div><button type="button" className="close-button" onClick={onClose} aria-label="Close"><X /></button></div><div className="form-body">{error && <div className="form-validation-summary">{error}</div>}<div className="field"><label>Display name</label><input className="field-input" value={String(values.display_name ?? '')} onChange={(e) => set('display_name', e.target.value)} required maxLength={120} /></div>{countryField}{kind === 'country' && <div className="field"><label>Country code</label><input className="field-input" value={String(values.country_code ?? '')} onChange={(e) => set('country_code', e.target.value.toUpperCase().slice(0, 2))} required maxLength={2} placeholder="XY" /></div>}{kind === 'region' && <><div className="field"><label>Parent region</label><select className="field-select" value={String(values.parent_region_id ?? '')} onChange={(e) => set('parent_region_id', e.target.value)}><option value="">No parent region</option>{parentOptions.map((r) => <option key={r.id} value={r.id}>{r.display_name}</option>)}</select></div><div className="field"><label>Region code</label><input className="field-input" value={String(values.region_code ?? '')} onChange={(e) => set('region_code', e.target.value)} /></div><div className="field"><label>Region type</label><input className="field-input" value={String(values.region_type ?? '')} onChange={(e) => set('region_type', e.target.value)} placeholder="Province, state, district" /></div></>}{kind === 'system' && <><div className="field"><label>Region (optional)</label><select className="field-select" value={String(values.region_id ?? '')} onChange={(e) => set('region_id', e.target.value)}><option value="">Country-wide</option>{parentOptions.map((r) => <option key={r.id} value={r.id}>{r.display_name}</option>)}</select></div><div className="field"><label>System code (optional)</label><input className="field-input" value={String(values.system_code ?? '')} onChange={(e) => set('system_code', e.target.value)} /></div></>}{item && !item.is_active && <div className="select-empty"><CircleAlert />This record stays inactive after editing.</div>}</div><div className="form-footer"><button type="button" className="button button-secondary" onClick={onClose}>Cancel</button><button type="submit" className="button button-primary"><Check />{item ? 'Save changes' : `Add ${kindInfo[kind].singular}`}</button></div></form></div>;
}

function downstream(kind: Kind, id: string, regions: Region[], systems: EducationalSystem[]): Record<string, number> {
  if (kind === 'country') return { regions: regions.filter((r) => r.country_id === id).length, systems: systems.filter((s) => s.country_id === id).length };
  if (kind === 'region') return { systems: systems.filter((s) => s.region_id === id).length };
  return {};
}

function ConfirmDialog({ kind, item, dependencies, onCancel, onConfirm }: { kind: Kind; item: CatalogItem; dependencies: Record<string, number>; onCancel: () => void; onConfirm: () => void }) {
  const dependencyText = Object.entries(dependencies).filter(([, count]) => count).map(([label, count]) => `${count} ${label}`).join(' and ');
  return <div className="confirm-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onCancel(); }}><div className="confirm-card" role="dialog" aria-modal="true"><div className="empty-icon" style={{ margin: '0 0 16px', color: item.is_active ? '#a26051' : '#537969', background: item.is_active ? '#f4e8df' : '#e7efe6' }}>{item.is_active ? <Archive /> : <RotateCcw />}</div><h2>{item.is_active ? 'Deactivate' : 'Reactivate'} {kindInfo[kind].singular}?</h2><p><strong>{item.display_name}</strong> will be {item.is_active ? 'hidden from active selections' : 'available for active selections'} in the global catalog. {dependencyText && `It has ${dependencyText}; dependent records will remain unchanged.`}</p><div className="confirm-actions"><button className="button button-secondary" onClick={onCancel}>Cancel</button><button className={item.is_active ? 'button button-danger' : 'button button-primary'} onClick={onConfirm}>{item.is_active ? 'Deactivate' : 'Reactivate'}</button></div></div></div>;
}

function NotFound() {
  return <div className="empty-state"><div className="empty-icon"><CircleAlert /></div><h2>Page not found</h2><p>This workspace route is not available.</p><Link href="/" className="button button-primary">Return to overview</Link></div>;
}

export default App;