import { createClient } from '@supabase/supabase-js';

const url = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim() ?? '';
const anonKey =
  (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim() ?? '';

let validHttpUrl = false;
try {
  const parsed = new URL(url);
  validHttpUrl = parsed.protocol === 'https:' || parsed.protocol === 'http:';
} catch {
  validHttpUrl = false;
}

export const supabaseConfigurationError = !url
  ? 'The Supabase project URL is missing.'
  : !validHttpUrl
    ? 'The Supabase URL must be a full HTTP or HTTPS project API URL, such as https://<project-ref>.supabase.co. Do not use a Postgres connection string.'
    : !anonKey
      ? 'The public Supabase anon key is missing.'
      : '';
export const supabaseConfigured = supabaseConfigurationError.length === 0;
export const supabase = supabaseConfigured
  ? createClient(url, anonKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    })
  : null;