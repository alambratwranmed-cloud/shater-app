---
name: Supabase client key
description: Which existing Supabase key is safe to bundle into Shatir browser apps.
---

`SUPABASE_KEY` is the public anon key, as confirmed by the user. It may be bundled into a browser app only for operations protected by Supabase RLS. Never use a service-role key in the browser or disable RLS.

**Why:** Shatir's browser apps use Supabase Auth and RLS-protected client queries; the key's role is not derivable from its name alone.

**How to apply:** Map `SUPABASE_KEY` only to a frontend anon-key setting. Keep any service-role key server-side.