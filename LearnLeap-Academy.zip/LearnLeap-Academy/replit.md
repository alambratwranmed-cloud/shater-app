# Shatir | شاطر

Shatir is a multi-tenant, global education platform with database-managed country, curriculum, learning, and pricing configuration.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `supabase/migrations/` — versioned Supabase PostgreSQL schema; apply migrations in filename order.
- `supabase/README.md` — setup, migration, security, and bootstrap notes.
- `lib/api-spec/openapi.yaml` — source of truth for API contracts.
- `artifacts/api-server/` — shared Express API service.
- `lib/db/` — existing Drizzle package for the Replit-managed database; it is not the Shatir Supabase schema source of truth.

## Architecture decisions

- Supabase SQL migrations are the source of truth for Shatir's external PostgreSQL schema.
- Global catalogs and pricing are database-managed; migrations create schema only and do not seed country-, language-, currency-, curriculum-, or price-specific records.
- Published learning content is linked to a curriculum offering; RLS allows student content reads only through an active matching offering context.
- The Supabase service-role key and database connection string must stay server-side and must never be shipped in a client app.

## Product

Shatir is being built as a global education platform. The current foundation covers tenant, taxonomy, learning, progress, assessment, payment, reporting, and content-version schema. Product modules are staged separately.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Apply Supabase migrations to the intended Supabase project explicitly; Replit Publish does not apply them.
- No taxonomy, language, currency, region, or pricing records are seeded. The platform owner must populate these through the admin workflow or a controlled bootstrap.
- Never query student learning content without the active country, educational-system, and grade context; database RLS also enforces the selected curriculum offering.
- `SUPABASE_DB_URL` is a secret required only for automated migration application. It was not supplied, so the checked-in schema has not been applied to a live Supabase project.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
