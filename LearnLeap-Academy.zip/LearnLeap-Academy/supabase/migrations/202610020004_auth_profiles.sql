BEGIN;

CREATE OR REPLACE FUNCTION public.create_user_profile_for_auth_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  resolved_display_name text;
BEGIN
  resolved_display_name :=
    NULLIF(BTRIM(COALESCE(NEW.raw_user_meta_data ->> 'display_name', '')), '');

  IF resolved_display_name IS NULL THEN
    resolved_display_name := 'Student';
  END IF;

  INSERT INTO public.users (id, display_name)
  VALUES (NEW.id, resolved_display_name)
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.create_user_profile_for_auth_user()
  FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.create_user_profile_for_auth_user();

COMMIT;