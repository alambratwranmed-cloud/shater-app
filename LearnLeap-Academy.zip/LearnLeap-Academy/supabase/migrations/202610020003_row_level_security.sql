BEGIN;

CREATE OR REPLACE FUNCTION app_private.is_platform_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.admins a
    JOIN public.roles r ON r.id = a.role_id
    JOIN public.role_permissions rp ON rp.role_id = r.id
    JOIN public.permissions p ON p.id = rp.permission_id
    WHERE a.user_id = auth.uid()
      AND a.tenant_id IS NULL
      AND a.is_active
      AND r.is_active
      AND r.role_scope = 'platform'
      AND r.tenant_id IS NULL
      AND p.permission_key = 'platform.manage'
  );
$$;

CREATE OR REPLACE FUNCTION app_private.is_tenant_member(target_tenant_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT target_tenant_id IS NOT NULL AND EXISTS (
    SELECT 1
    FROM public.tenant_memberships tm
    WHERE tm.tenant_id = target_tenant_id
      AND tm.user_id = auth.uid()
      AND tm.status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION app_private.can_manage_tenant(target_tenant_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT app_private.is_platform_admin()
    OR (
      target_tenant_id IS NOT NULL
      AND EXISTS (
        SELECT 1
        FROM public.admins a
        JOIN public.roles r ON r.id = a.role_id
        JOIN public.role_permissions rp ON rp.role_id = r.id
        JOIN public.permissions p ON p.id = rp.permission_id
        WHERE a.user_id = auth.uid()
          AND a.tenant_id = target_tenant_id
          AND a.is_active
          AND r.is_active
          AND r.role_scope = 'tenant'
          AND r.tenant_id = target_tenant_id
          AND p.permission_key = 'tenant.manage'
      )
    );
$$;

CREATE OR REPLACE FUNCTION app_private.can_access_student(
  target_student_id uuid,
  target_tenant_id uuid
)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT app_private.can_manage_tenant(target_tenant_id)
    OR EXISTS (
      SELECT 1
      FROM public.students s
      WHERE s.id = target_student_id
        AND s.tenant_id = target_tenant_id
        AND (
          s.auth_user_id = auth.uid()
          OR (
            s.guardian_user_id = auth.uid()
            AND app_private.is_tenant_member(s.tenant_id)
          )
        )
    );
$$;

CREATE OR REPLACE FUNCTION app_private.can_assign_offering(
  target_student_id uuid,
  target_tenant_id uuid,
  target_offering_id uuid
)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT app_private.can_access_student(target_student_id, target_tenant_id)
    AND EXISTS (
      SELECT 1
      FROM public.curriculum_offerings co
      WHERE co.id = target_offering_id
        AND co.is_active
        AND co.publication_state = 'published'
        AND (co.tenant_id IS NULL OR co.tenant_id = target_tenant_id)
    );
$$;

CREATE OR REPLACE FUNCTION app_private.can_read_offering(
  target_offering_id uuid,
  row_tenant_id uuid,
  row_publication_state text
)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT app_private.is_platform_admin()
    OR app_private.can_manage_tenant(row_tenant_id)
    OR (
      row_publication_state = 'published'
      AND EXISTS (
        SELECT 1
        FROM public.student_learning_contexts slc
        JOIN public.students s
          ON s.id = slc.student_id
         AND s.tenant_id = slc.tenant_id
        WHERE slc.curriculum_offering_id = target_offering_id
          AND slc.is_active
          AND (s.auth_user_id = auth.uid() OR s.guardian_user_id = auth.uid())
          AND (row_tenant_id IS NULL OR row_tenant_id = s.tenant_id)
          AND EXISTS (
            SELECT 1
            FROM public.curriculum_offerings co
            WHERE co.id = target_offering_id
              AND co.is_active
              AND co.publication_state = 'published'
              AND (co.tenant_id IS NULL OR co.tenant_id = s.tenant_id)
          )
      )
    );
$$;

CREATE OR REPLACE FUNCTION app_private.can_manage_user_report(
  target_user_id uuid,
  target_tenant_id uuid
)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT target_user_id = auth.uid()
    OR app_private.can_manage_tenant(target_tenant_id);
$$;

CREATE OR REPLACE FUNCTION app_private.can_access_payment(
  target_tenant_id uuid,
  target_subscription_id uuid
)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT app_private.can_manage_tenant(target_tenant_id)
    OR EXISTS (
      SELECT 1
      FROM public.subscriptions sub
      JOIN public.students s
        ON s.id = sub.student_id
       AND s.tenant_id = sub.tenant_id
      WHERE sub.id = target_subscription_id
        AND sub.tenant_id = target_tenant_id
        AND app_private.can_access_student(s.id, s.tenant_id)
    );
$$;

CREATE OR REPLACE FUNCTION app_private.validate_role_assignment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
DECLARE
  assigned_role_scope text;
  assigned_role_tenant_id uuid;
BEGIN
  SELECT r.role_scope, r.tenant_id
    INTO assigned_role_scope, assigned_role_tenant_id
  FROM public.roles r
  WHERE r.id = NEW.role_id
    AND r.is_active;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'The selected role does not exist or is inactive';
  END IF;

  IF TG_TABLE_NAME = 'tenant_memberships' THEN
    IF NEW.tenant_id IS NULL
       OR assigned_role_scope <> 'tenant'
       OR assigned_role_tenant_id IS DISTINCT FROM NEW.tenant_id THEN
      RAISE EXCEPTION 'Tenant memberships require a role from the same tenant';
    END IF;
  ELSIF NEW.tenant_id IS NULL THEN
    IF assigned_role_scope <> 'platform' OR assigned_role_tenant_id IS NOT NULL THEN
      RAISE EXCEPTION 'Platform administrator assignments require a platform role';
    END IF;
  ELSIF assigned_role_scope <> 'tenant'
        OR assigned_role_tenant_id IS DISTINCT FROM NEW.tenant_id THEN
    RAISE EXCEPTION 'Tenant administrator assignments require a role from the same tenant';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER tenant_memberships_validate_role
  BEFORE INSERT OR UPDATE OF tenant_id, role_id ON public.tenant_memberships
  FOR EACH ROW EXECUTE FUNCTION app_private.validate_role_assignment();

CREATE TRIGGER admins_validate_role
  BEFORE INSERT OR UPDATE OF tenant_id, role_id ON public.admins
  FOR EACH ROW EXECUTE FUNCTION app_private.validate_role_assignment();

REVOKE ALL ON ALL FUNCTIONS IN SCHEMA app_private FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION app_private.is_platform_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION app_private.is_tenant_member(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION app_private.can_manage_tenant(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION app_private.can_access_student(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION app_private.can_assign_offering(uuid, uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION app_private.can_read_offering(uuid, uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION app_private.can_manage_user_report(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION app_private.can_access_payment(uuid, uuid) TO authenticated;

GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO service_role;
GRANT USAGE ON SCHEMA app_private TO authenticated;

DO $$
DECLARE
  table_name text;
BEGIN
  FOREACH table_name IN ARRAY ARRAY[
    'languages', 'currencies', 'countries', 'regions', 'tenants', 'users',
    'roles', 'permissions', 'role_permissions', 'tenant_memberships', 'admins',
    'educational_systems', 'curricula', 'academic_years', 'stages', 'grades',
    'tracks', 'subjects', 'curriculum_offerings', 'students',
    'student_learning_contexts', 'units', 'lessons', 'questions',
    'question_options', 'question_answer_keys', 'exams', 'exam_questions',
    'exam_attempts', 'student_progress', 'achievements', 'student_achievements',
    'subscription_plans', 'subscription_prices', 'subscriptions', 'payments',
    'reports', 'content_versions', 'platform_parameters'
  ] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', table_name);
  END LOOP;
END;
$$;

CREATE POLICY languages_read_active ON public.languages
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY languages_platform_manage ON public.languages
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY currencies_read_active ON public.currencies
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY currencies_platform_manage ON public.currencies
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY countries_read_active ON public.countries
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY countries_platform_manage ON public.countries
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY regions_read_active ON public.regions
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY regions_platform_manage ON public.regions
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY systems_read_active ON public.educational_systems
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY systems_platform_manage ON public.educational_systems
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY tenants_read_members ON public.tenants
  FOR SELECT TO authenticated
  USING (app_private.is_tenant_member(id) OR app_private.can_manage_tenant(id));
CREATE POLICY tenants_admin_manage ON public.tenants
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(id))
  WITH CHECK (app_private.can_manage_tenant(id));

CREATE POLICY users_read_self ON public.users
  FOR SELECT TO authenticated USING (id = auth.uid());
CREATE POLICY users_update_self ON public.users
  FOR UPDATE TO authenticated USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

CREATE POLICY roles_read_scope ON public.roles
  FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR app_private.is_tenant_member(tenant_id)
      OR app_private.can_manage_tenant(tenant_id));
CREATE POLICY roles_admin_manage ON public.roles
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY permissions_read_authenticated ON public.permissions
  FOR SELECT TO authenticated USING (true);
CREATE POLICY permissions_platform_manage ON public.permissions
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY role_permissions_read_scope ON public.role_permissions
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.roles r
    WHERE r.id = role_id
      AND (r.tenant_id IS NULL OR app_private.is_tenant_member(r.tenant_id)
        OR app_private.can_manage_tenant(r.tenant_id))
  ));
CREATE POLICY role_permissions_admin_manage ON public.role_permissions
  FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.roles r
    WHERE r.id = role_id AND app_private.can_manage_tenant(r.tenant_id)
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.roles r
    WHERE r.id = role_id AND app_private.can_manage_tenant(r.tenant_id)
  ));

CREATE POLICY memberships_read_scope ON public.tenant_memberships
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR app_private.can_manage_tenant(tenant_id));
CREATE POLICY memberships_admin_manage ON public.tenant_memberships
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY admins_read_self_or_admin ON public.admins
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR app_private.can_manage_tenant(tenant_id));
CREATE POLICY admins_platform_manage ON public.admins
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY curricula_read_published ON public.curricula
  FOR SELECT TO authenticated
  USING ((publication_state = 'published' AND is_active
      AND (tenant_id IS NULL OR app_private.is_tenant_member(tenant_id)))
    OR app_private.can_manage_tenant(tenant_id));
CREATE POLICY curricula_admin_manage ON public.curricula
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY years_read_active ON public.academic_years
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY years_platform_manage ON public.academic_years
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY stages_read_active ON public.stages
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY stages_platform_manage ON public.stages
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY grades_read_active ON public.grades
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY grades_platform_manage ON public.grades
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY tracks_read_active ON public.tracks
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY tracks_platform_manage ON public.tracks
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY subjects_read_active ON public.subjects
  FOR SELECT TO authenticated USING (is_active OR app_private.is_platform_admin());
CREATE POLICY subjects_platform_manage ON public.subjects
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY offerings_read_published ON public.curriculum_offerings
  FOR SELECT TO authenticated
  USING ((is_active AND publication_state = 'published'
      AND (tenant_id IS NULL OR app_private.is_tenant_member(tenant_id)))
    OR app_private.can_manage_tenant(tenant_id));
CREATE POLICY offerings_admin_manage ON public.curriculum_offerings
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY students_read_related ON public.students
  FOR SELECT TO authenticated
  USING (app_private.can_access_student(id, tenant_id));
CREATE POLICY students_admin_manage ON public.students
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY learning_contexts_read_related ON public.student_learning_contexts
  FOR SELECT TO authenticated
  USING (app_private.can_access_student(student_id, tenant_id));
CREATE POLICY learning_contexts_manage_related ON public.student_learning_contexts
  FOR ALL TO authenticated
  USING (app_private.can_access_student(student_id, tenant_id))
  WITH CHECK (
    app_private.can_assign_offering(student_id, tenant_id, curriculum_offering_id)
  );

CREATE POLICY units_read_context ON public.units
  FOR SELECT TO authenticated
  USING (is_active AND app_private.can_read_offering(
    curriculum_offering_id, tenant_id, publication_state
  ));
CREATE POLICY units_admin_manage ON public.units
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY lessons_read_context ON public.lessons
  FOR SELECT TO authenticated
  USING (is_active AND app_private.can_read_offering(
    curriculum_offering_id, tenant_id, publication_state
  ));
CREATE POLICY lessons_admin_manage ON public.lessons
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY questions_read_context ON public.questions
  FOR SELECT TO authenticated
  USING (is_active AND app_private.can_read_offering(
    curriculum_offering_id, tenant_id, publication_state
  ));
CREATE POLICY questions_admin_manage ON public.questions
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY options_read_context ON public.question_options
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.questions q
    WHERE q.id = question_options.question_id
      AND q.curriculum_offering_id = question_options.curriculum_offering_id
      AND q.is_active
      AND app_private.can_read_offering(
        q.curriculum_offering_id, q.tenant_id, q.publication_state
      )
  ));
CREATE POLICY options_admin_manage ON public.question_options
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY answer_keys_admin_only ON public.question_answer_keys
  FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1
    FROM public.questions q
    WHERE q.id = question_id
      AND app_private.can_manage_tenant(q.tenant_id)
  ))
  WITH CHECK (EXISTS (
    SELECT 1
    FROM public.questions q
    WHERE q.id = question_id
      AND app_private.can_manage_tenant(q.tenant_id)
  ));

CREATE POLICY exams_read_context ON public.exams
  FOR SELECT TO authenticated
  USING (is_active AND app_private.can_read_offering(
    curriculum_offering_id, tenant_id, publication_state
  ));
CREATE POLICY exams_admin_manage ON public.exams
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY exam_questions_read_context ON public.exam_questions
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.exams e
    WHERE e.id = exam_questions.exam_id
      AND e.curriculum_offering_id = exam_questions.curriculum_offering_id
      AND e.is_active
      AND app_private.can_read_offering(
        e.curriculum_offering_id, e.tenant_id, e.publication_state
      )
  ));
CREATE POLICY exam_questions_admin_manage ON public.exam_questions
  FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.exams e
    WHERE e.id = exam_id AND app_private.can_manage_tenant(e.tenant_id)
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.exams e
    WHERE e.id = exam_id AND app_private.can_manage_tenant(e.tenant_id)
  ));

CREATE POLICY attempts_read_related ON public.exam_attempts
  FOR SELECT TO authenticated
  USING (app_private.can_access_student(student_id, tenant_id));
CREATE POLICY attempts_admin_manage ON public.exam_attempts
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY progress_read_related ON public.student_progress
  FOR SELECT TO authenticated
  USING (app_private.can_access_student(student_id, tenant_id));
CREATE POLICY progress_admin_manage ON public.student_progress
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY achievements_read_context ON public.achievements
  FOR SELECT TO authenticated
  USING (app_private.can_read_offering(
    curriculum_offering_id, tenant_id, publication_state
  ));
CREATE POLICY achievements_admin_manage ON public.achievements
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY student_achievements_read_related ON public.student_achievements
  FOR SELECT TO authenticated
  USING (app_private.can_access_student(student_id, tenant_id));
CREATE POLICY student_achievements_admin_manage ON public.student_achievements
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY plans_read_active ON public.subscription_plans
  FOR SELECT TO authenticated
  USING ((is_active AND (tenant_id IS NULL OR app_private.is_tenant_member(tenant_id)))
    OR app_private.can_manage_tenant(tenant_id));
CREATE POLICY plans_admin_manage ON public.subscription_plans
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY prices_read_active ON public.subscription_prices
  FOR SELECT TO authenticated
  USING (
    (is_active AND EXISTS (
      SELECT 1 FROM public.subscription_plans sp
      WHERE sp.id = plan_id
        AND (sp.tenant_id IS NULL OR app_private.is_tenant_member(sp.tenant_id))
    ))
    OR app_private.is_platform_admin()
  );
CREATE POLICY prices_platform_manage ON public.subscription_prices
  FOR ALL TO authenticated
  USING (app_private.is_platform_admin())
  WITH CHECK (app_private.is_platform_admin());

CREATE POLICY subscriptions_read_related ON public.subscriptions
  FOR SELECT TO authenticated
  USING (app_private.can_access_student(student_id, tenant_id));
CREATE POLICY subscriptions_admin_manage ON public.subscriptions
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY payments_read_related ON public.payments
  FOR SELECT TO authenticated
  USING (app_private.can_access_payment(tenant_id, subscription_id));
CREATE POLICY payments_admin_manage ON public.payments
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY reports_read_related ON public.reports
  FOR SELECT TO authenticated
  USING (app_private.can_manage_user_report(submitted_by, tenant_id));
CREATE POLICY reports_submit_self ON public.reports
  FOR INSERT TO authenticated
  WITH CHECK (
    submitted_by = auth.uid()
    AND (tenant_id IS NULL OR app_private.is_tenant_member(tenant_id))
  );
CREATE POLICY reports_admin_manage ON public.reports
  FOR UPDATE TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY content_versions_admin_only ON public.content_versions
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE POLICY parameters_read_active ON public.platform_parameters
  FOR SELECT TO authenticated
  USING (is_active AND (tenant_id IS NULL OR app_private.is_tenant_member(tenant_id)));
CREATE POLICY parameters_platform_manage ON public.platform_parameters
  FOR ALL TO authenticated
  USING (app_private.can_manage_tenant(tenant_id))
  WITH CHECK (app_private.can_manage_tenant(tenant_id));

CREATE INDEX regions_country_active_idx
  ON public.regions (country_id, is_active);
CREATE INDEX educational_systems_country_region_idx
  ON public.educational_systems (country_id, region_id, is_active);
CREATE INDEX curricula_system_state_idx
  ON public.curricula (country_id, educational_system_id, publication_state);
CREATE INDEX curriculum_offerings_tenant_state_idx
  ON public.curriculum_offerings (tenant_id, publication_state, is_active);
CREATE INDEX units_context_order_idx
  ON public.units (curriculum_offering_id, subject_id, sort_order)
  WHERE is_active = true AND publication_state = 'published';
CREATE INDEX lessons_context_order_idx
  ON public.lessons (curriculum_offering_id, unit_id, sort_order)
  WHERE is_active = true AND publication_state = 'published';
CREATE INDEX questions_context_lesson_idx
  ON public.questions (curriculum_offering_id, lesson_id, question_type)
  WHERE is_active = true AND publication_state = 'published';
CREATE INDEX options_question_order_idx
  ON public.question_options (question_id, position);
CREATE INDEX exams_context_state_idx
  ON public.exams (curriculum_offering_id, publication_state, is_active);
CREATE INDEX attempts_student_recent_idx
  ON public.exam_attempts (tenant_id, student_id, started_at DESC);
CREATE INDEX progress_student_activity_idx
  ON public.student_progress (tenant_id, student_id, last_activity_at DESC);
CREATE INDEX payments_subscription_created_idx
  ON public.payments (tenant_id, subscription_id, created_at DESC);
CREATE INDEX reports_queue_idx
  ON public.reports (tenant_id, status, created_at DESC);
CREATE INDEX content_versions_entity_idx
  ON public.content_versions (tenant_id, entity_type, entity_id, version_number DESC);

COMMIT;