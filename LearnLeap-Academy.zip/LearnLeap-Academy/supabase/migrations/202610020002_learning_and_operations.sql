BEGIN;

CREATE TABLE public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  auth_user_id uuid UNIQUE REFERENCES public.users(id) ON DELETE SET NULL,
  guardian_user_id uuid REFERENCES public.users(id) ON DELETE SET NULL,
  display_name text NOT NULL,
  preferred_language_id uuid REFERENCES public.languages(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'suspended', 'archived')),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, tenant_id),
  CHECK (auth_user_id IS NOT NULL OR guardian_user_id IS NOT NULL)
);

CREATE TABLE public.student_learning_contexts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL,
  tenant_id uuid NOT NULL,
  curriculum_offering_id uuid NOT NULL
    REFERENCES public.curriculum_offerings(id) ON DELETE RESTRICT,
  is_active boolean NOT NULL DEFAULT true,
  assigned_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  selected_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, curriculum_offering_id),
  FOREIGN KEY (student_id, tenant_id)
    REFERENCES public.students(id, tenant_id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX student_one_active_learning_context_uq
  ON public.student_learning_contexts (student_id)
  WHERE is_active = true;

CREATE TABLE public.units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  curriculum_offering_id uuid NOT NULL,
  subject_id uuid NOT NULL,
  track_id uuid NOT NULL,
  grade_id uuid NOT NULL,
  curriculum_id uuid NOT NULL,
  unit_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(description_i18n) = 'object'),
  sort_order integer NOT NULL DEFAULT 0,
  publication_state text NOT NULL DEFAULT 'draft'
    CHECK (publication_state IN
      ('draft', 'under_review', 'approved', 'published', 'archived')),
  is_active boolean NOT NULL DEFAULT true,
  content jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(content) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_offering_id),
  FOREIGN KEY (subject_id, track_id, grade_id, curriculum_id)
    REFERENCES public.subjects(id, track_id, grade_id, curriculum_id)
    ON DELETE RESTRICT,
  FOREIGN KEY (curriculum_offering_id, grade_id, curriculum_id, track_id)
    REFERENCES public.curriculum_offerings(id, grade_id, curriculum_id, track_id)
    ON DELETE CASCADE
);

CREATE TABLE public.lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  curriculum_offering_id uuid NOT NULL
    REFERENCES public.curriculum_offerings(id) ON DELETE CASCADE,
  unit_id uuid NOT NULL,
  lesson_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  summary_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(summary_i18n) = 'object'),
  sort_order integer NOT NULL DEFAULT 0,
  estimated_minutes integer CHECK (estimated_minutes IS NULL OR estimated_minutes > 0),
  publication_state text NOT NULL DEFAULT 'draft'
    CHECK (publication_state IN
      ('draft', 'under_review', 'approved', 'published', 'archived')),
  is_active boolean NOT NULL DEFAULT true,
  content jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(content) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_offering_id),
  FOREIGN KEY (unit_id, curriculum_offering_id)
    REFERENCES public.units(id, curriculum_offering_id) ON DELETE CASCADE
);

CREATE TABLE public.questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  curriculum_offering_id uuid NOT NULL
    REFERENCES public.curriculum_offerings(id) ON DELETE CASCADE,
  lesson_id uuid,
  question_type text NOT NULL
    CHECK (question_type IN ('multiple_choice', 'true_false', 'matching', 'short_answer')),
  prompt_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(prompt_i18n) = 'object'),
  question_payload jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(question_payload) = 'object'),
  points numeric(10, 2) NOT NULL DEFAULT 1 CHECK (points >= 0),
  difficulty text,
  publication_state text NOT NULL DEFAULT 'draft'
    CHECK (publication_state IN
      ('draft', 'under_review', 'approved', 'published', 'archived')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_offering_id),
  FOREIGN KEY (lesson_id, curriculum_offering_id)
    REFERENCES public.lessons(id, curriculum_offering_id) ON DELETE CASCADE
);

CREATE TABLE public.question_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  question_id uuid NOT NULL,
  curriculum_offering_id uuid NOT NULL,
  position integer NOT NULL CHECK (position >= 0),
  option_payload jsonb NOT NULL
    CHECK (jsonb_typeof(option_payload) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (question_id, position),
  UNIQUE (id, question_id),
  FOREIGN KEY (question_id, curriculum_offering_id)
    REFERENCES public.questions(id, curriculum_offering_id) ON DELETE CASCADE
);

CREATE TABLE public.question_answer_keys (
  question_id uuid PRIMARY KEY
    REFERENCES public.questions(id) ON DELETE CASCADE,
  answer_payload jsonb NOT NULL
    CHECK (jsonb_typeof(answer_payload) = 'object'),
  grading_rules jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(grading_rules) = 'object'),
  updated_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  curriculum_offering_id uuid NOT NULL
    REFERENCES public.curriculum_offerings(id) ON DELETE CASCADE,
  exam_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  instructions_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(instructions_i18n) = 'object'),
  assessment_type text,
  duration_seconds integer CHECK (duration_seconds IS NULL OR duration_seconds > 0),
  max_attempts integer CHECK (max_attempts IS NULL OR max_attempts > 0),
  publication_state text NOT NULL DEFAULT 'draft'
    CHECK (publication_state IN
      ('draft', 'under_review', 'approved', 'published', 'archived')),
  is_active boolean NOT NULL DEFAULT true,
  settings jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(settings) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_offering_id)
);

CREATE TABLE public.exam_questions (
  exam_id uuid NOT NULL,
  question_id uuid NOT NULL,
  curriculum_offering_id uuid NOT NULL,
  position integer NOT NULL CHECK (position >= 0),
  points_override numeric(10, 2) CHECK (points_override IS NULL OR points_override >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (exam_id, question_id),
  UNIQUE (exam_id, position),
  FOREIGN KEY (exam_id, curriculum_offering_id)
    REFERENCES public.exams(id, curriculum_offering_id) ON DELETE CASCADE,
  FOREIGN KEY (question_id, curriculum_offering_id)
    REFERENCES public.questions(id, curriculum_offering_id) ON DELETE RESTRICT
);

CREATE TABLE public.exam_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  student_id uuid NOT NULL,
  exam_id uuid NOT NULL,
  curriculum_offering_id uuid NOT NULL,
  attempt_number integer NOT NULL CHECK (attempt_number > 0),
  status text NOT NULL DEFAULT 'in_progress'
    CHECK (status IN ('in_progress', 'submitted', 'graded', 'voided')),
  responses jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(responses) = 'object'),
  score numeric(10, 2) CHECK (score IS NULL OR score >= 0),
  max_score numeric(10, 2) CHECK (max_score IS NULL OR max_score >= 0),
  started_at timestamptz NOT NULL DEFAULT now(),
  submitted_at timestamptz,
  graded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, exam_id, attempt_number),
  FOREIGN KEY (student_id, tenant_id)
    REFERENCES public.students(id, tenant_id) ON DELETE CASCADE,
  FOREIGN KEY (exam_id, curriculum_offering_id)
    REFERENCES public.exams(id, curriculum_offering_id) ON DELETE CASCADE
);

CREATE TABLE public.student_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  student_id uuid NOT NULL,
  curriculum_offering_id uuid NOT NULL,
  lesson_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'not_started'
    CHECK (status IN ('not_started', 'in_progress', 'completed')),
  completion_percent numeric(5, 2) NOT NULL DEFAULT 0
    CHECK (completion_percent BETWEEN 0 AND 100),
  progress_data jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(progress_data) = 'object'),
  first_started_at timestamptz,
  completed_at timestamptz,
  last_activity_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, lesson_id),
  FOREIGN KEY (student_id, tenant_id)
    REFERENCES public.students(id, tenant_id) ON DELETE CASCADE,
  FOREIGN KEY (lesson_id, curriculum_offering_id)
    REFERENCES public.lessons(id, curriculum_offering_id) ON DELETE CASCADE
);

CREATE TABLE public.achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  curriculum_offering_id uuid NOT NULL
    REFERENCES public.curriculum_offerings(id) ON DELETE CASCADE,
  achievement_code text,
  display_name text NOT NULL,
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(description_i18n) = 'object'),
  criteria jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(criteria) = 'object'),
  publication_state text NOT NULL DEFAULT 'draft'
    CHECK (publication_state IN
      ('draft', 'under_review', 'approved', 'published', 'archived')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_offering_id)
);

CREATE TABLE public.student_achievements (
  tenant_id uuid NOT NULL,
  student_id uuid NOT NULL,
  achievement_id uuid NOT NULL,
  curriculum_offering_id uuid NOT NULL,
  awarded_at timestamptz NOT NULL DEFAULT now(),
  awarded_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  evidence jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(evidence) = 'object'),
  PRIMARY KEY (student_id, achievement_id),
  FOREIGN KEY (student_id, tenant_id)
    REFERENCES public.students(id, tenant_id) ON DELETE CASCADE,
  FOREIGN KEY (achievement_id, curriculum_offering_id)
    REFERENCES public.achievements(id, curriculum_offering_id) ON DELETE CASCADE
);

CREATE TABLE public.subscription_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  plan_code text NOT NULL,
  display_name text NOT NULL,
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(description_i18n) = 'object'),
  billing_interval text NOT NULL
    CHECK (billing_interval IN ('day', 'week', 'month', 'year', 'one_time')),
  interval_count integer NOT NULL DEFAULT 1 CHECK (interval_count > 0),
  is_active boolean NOT NULL DEFAULT true,
  features jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(features) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX subscription_plans_global_code_uq
  ON public.subscription_plans (plan_code) WHERE tenant_id IS NULL;
CREATE UNIQUE INDEX subscription_plans_tenant_code_uq
  ON public.subscription_plans (tenant_id, plan_code) WHERE tenant_id IS NOT NULL;

CREATE TABLE public.subscription_prices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL REFERENCES public.subscription_plans(id) ON DELETE CASCADE,
  country_id uuid REFERENCES public.countries(id) ON DELETE CASCADE,
  region_id uuid REFERENCES public.regions(id) ON DELETE CASCADE,
  currency_id uuid NOT NULL REFERENCES public.currencies(id) ON DELETE RESTRICT,
  amount numeric(18, 6) NOT NULL CHECK (amount >= 0),
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_until timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (valid_until IS NULL OR valid_until > valid_from)
);

CREATE TABLE public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  student_id uuid NOT NULL,
  plan_id uuid NOT NULL REFERENCES public.subscription_plans(id) ON DELETE RESTRICT,
  price_id uuid REFERENCES public.subscription_prices(id) ON DELETE SET NULL,
  currency_id uuid NOT NULL REFERENCES public.currencies(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'trialing', 'active', 'past_due', 'canceled', 'expired')),
  amount_at_purchase numeric(18, 6) NOT NULL CHECK (amount_at_purchase >= 0),
  started_at timestamptz,
  current_period_start timestamptz,
  current_period_end timestamptz,
  canceled_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, tenant_id),
  FOREIGN KEY (student_id, tenant_id)
    REFERENCES public.students(id, tenant_id) ON DELETE CASCADE,
  CHECK (current_period_end IS NULL OR current_period_start IS NULL
      OR current_period_end >= current_period_start)
);

CREATE INDEX subscriptions_student_status_idx
  ON public.subscriptions (tenant_id, student_id, status);

CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  subscription_id uuid NOT NULL,
  currency_id uuid NOT NULL REFERENCES public.currencies(id) ON DELETE RESTRICT,
  amount numeric(18, 6) NOT NULL CHECK (amount >= 0),
  status text NOT NULL DEFAULT 'submitted'
    CHECK (status IN ('submitted', 'under_review', 'approved', 'rejected', 'refunded')),
  payment_method text,
  proof_object_path text,
  provider_reference text,
  reviewed_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  review_note text,
  paid_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (subscription_id, tenant_id)
    REFERENCES public.subscriptions(id, tenant_id) ON DELETE CASCADE
);

CREATE TABLE public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  submitted_by uuid NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  report_type text NOT NULL,
  target_type text,
  target_id uuid,
  details text NOT NULL,
  status text NOT NULL DEFAULT 'open'
    CHECK (status IN ('open', 'under_review', 'resolved', 'dismissed')),
  resolution_note text,
  resolved_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  resolved_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.content_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  curriculum_offering_id uuid
    REFERENCES public.curriculum_offerings(id) ON DELETE CASCADE,
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  version_number integer NOT NULL CHECK (version_number > 0),
  workflow_state text NOT NULL DEFAULT 'draft'
    CHECK (workflow_state IN
      ('draft', 'under_review', 'approved', 'published', 'rejected', 'archived')),
  content_snapshot jsonb NOT NULL
    CHECK (jsonb_typeof(content_snapshot) = 'object'),
  change_note text,
  created_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  reviewed_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (entity_type, entity_id, version_number)
);

CREATE TABLE public.platform_parameters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  country_id uuid REFERENCES public.countries(id) ON DELETE CASCADE,
  region_id uuid,
  language_id uuid REFERENCES public.languages(id) ON DELETE CASCADE,
  parameter_key text NOT NULL,
  parameter_value jsonb NOT NULL,
  effective_from timestamptz NOT NULL DEFAULT now(),
  effective_until timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  updated_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (effective_until IS NULL OR effective_until > effective_from),
  FOREIGN KEY (region_id, country_id)
    REFERENCES public.regions(id, country_id) ON DELETE CASCADE
);

CREATE INDEX platform_parameters_lookup_idx
  ON public.platform_parameters
    (parameter_key, tenant_id, country_id, region_id, language_id, is_active);

DO $$
DECLARE
  table_name text;
BEGIN
  FOREACH table_name IN ARRAY ARRAY[
    'students', 'student_learning_contexts', 'units', 'lessons', 'questions',
    'exams', 'exam_attempts', 'student_progress', 'achievements',
    'subscription_plans', 'subscription_prices', 'subscriptions', 'payments',
    'reports', 'platform_parameters'
  ] LOOP
    EXECUTE format(
      'CREATE TRIGGER %I BEFORE UPDATE ON public.%I
       FOR EACH ROW EXECUTE FUNCTION app_private.touch_updated_at()',
      table_name || '_touch_updated_at',
      table_name
    );
  END LOOP;
END;
$$;

COMMIT;