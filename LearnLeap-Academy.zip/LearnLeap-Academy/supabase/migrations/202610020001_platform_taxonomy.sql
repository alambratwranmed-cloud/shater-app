BEGIN;

CREATE SCHEMA IF NOT EXISTS app_private;
REVOKE ALL ON SCHEMA app_private FROM PUBLIC;

CREATE OR REPLACE FUNCTION app_private.touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

CREATE TABLE public.languages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  locale_code text NOT NULL UNIQUE,
  display_name text NOT NULL,
  native_name text NOT NULL,
  writing_direction text NOT NULL
    CHECK (writing_direction IN ('ltr', 'rtl')),
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.currencies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  currency_code text NOT NULL UNIQUE
    CHECK (currency_code ~ '^[A-Z]{3}$'),
  display_name text NOT NULL,
  symbol text,
  minor_units smallint NOT NULL CHECK (minor_units BETWEEN 0 AND 6),
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.countries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_code text NOT NULL UNIQUE
    CHECK (country_code ~ '^[A-Z]{2}$'),
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  default_language_id uuid REFERENCES public.languages(id) ON DELETE SET NULL,
  default_currency_id uuid REFERENCES public.currencies(id) ON DELETE SET NULL,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.regions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id uuid NOT NULL REFERENCES public.countries(id) ON DELETE RESTRICT,
  parent_region_id uuid,
  region_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  region_type text,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, country_id),
  FOREIGN KEY (parent_region_id, country_id)
    REFERENCES public.regions(id, country_id) ON DELETE RESTRICT
);

CREATE TABLE public.tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_name text NOT NULL,
  tenant_slug text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'suspended', 'archived')),
  default_country_id uuid REFERENCES public.countries(id) ON DELETE SET NULL,
  default_region_id uuid REFERENCES public.regions(id) ON DELETE SET NULL,
  default_language_id uuid REFERENCES public.languages(id) ON DELETE SET NULL,
  default_currency_id uuid REFERENCES public.currencies(id) ON DELETE SET NULL,
  settings jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(settings) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  preferred_language_id uuid REFERENCES public.languages(id) ON DELETE SET NULL,
  avatar_path text,
  status text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'suspended', 'deleted')),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  role_key text NOT NULL,
  display_name text NOT NULL,
  role_scope text NOT NULL CHECK (role_scope IN ('platform', 'tenant')),
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((role_scope = 'platform' AND tenant_id IS NULL)
      OR (role_scope = 'tenant' AND tenant_id IS NOT NULL))
);

CREATE UNIQUE INDEX roles_platform_key_uq
  ON public.roles (role_key) WHERE tenant_id IS NULL;
CREATE UNIQUE INDEX roles_tenant_key_uq
  ON public.roles (tenant_id, role_key) WHERE tenant_id IS NOT NULL;

CREATE TABLE public.permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  permission_key text NOT NULL UNIQUE,
  display_name text NOT NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.role_permissions (
  role_id uuid NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
  permission_id uuid NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE public.tenant_memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  role_id uuid NOT NULL REFERENCES public.roles(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'active'
    CHECK (status IN ('invited', 'active', 'suspended', 'ended')),
  invited_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  joined_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, role_id)
);

CREATE TABLE public.admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  role_id uuid NOT NULL REFERENCES public.roles(id) ON DELETE RESTRICT,
  assigned_by uuid REFERENCES public.users(id) ON DELETE SET NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX admins_platform_role_uq
  ON public.admins (user_id, role_id) WHERE tenant_id IS NULL;
CREATE UNIQUE INDEX admins_tenant_role_uq
  ON public.admins (user_id, tenant_id, role_id) WHERE tenant_id IS NOT NULL;

CREATE TABLE public.educational_systems (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id uuid NOT NULL REFERENCES public.countries(id) ON DELETE RESTRICT,
  region_id uuid,
  system_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, country_id),
  FOREIGN KEY (region_id, country_id)
    REFERENCES public.regions(id, country_id) ON DELETE RESTRICT
);

CREATE TABLE public.curricula (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  country_id uuid NOT NULL REFERENCES public.countries(id) ON DELETE RESTRICT,
  educational_system_id uuid NOT NULL,
  curriculum_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  publication_state text NOT NULL DEFAULT 'draft'
    CHECK (publication_state IN
      ('draft', 'under_review', 'approved', 'published', 'archived')),
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, educational_system_id, country_id),
  FOREIGN KEY (educational_system_id, country_id)
    REFERENCES public.educational_systems(id, country_id) ON DELETE RESTRICT
);

CREATE TABLE public.academic_years (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  curriculum_id uuid NOT NULL REFERENCES public.curricula(id) ON DELETE CASCADE,
  year_code text NOT NULL,
  display_name text NOT NULL,
  starts_on date,
  ends_on date,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_id),
  UNIQUE (curriculum_id, year_code),
  CHECK (starts_on IS NULL OR ends_on IS NULL OR starts_on <= ends_on)
);

CREATE TABLE public.stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  curriculum_id uuid NOT NULL REFERENCES public.curricula(id) ON DELETE CASCADE,
  academic_year_id uuid NOT NULL,
  stage_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_id, academic_year_id),
  FOREIGN KEY (academic_year_id, curriculum_id)
    REFERENCES public.academic_years(id, curriculum_id) ON DELETE CASCADE
);

CREATE TABLE public.grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  curriculum_id uuid NOT NULL,
  academic_year_id uuid NOT NULL,
  stage_id uuid NOT NULL,
  grade_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, curriculum_id, academic_year_id, stage_id),
  FOREIGN KEY (stage_id, curriculum_id, academic_year_id)
    REFERENCES public.stages(id, curriculum_id, academic_year_id) ON DELETE CASCADE
);

CREATE TABLE public.tracks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  curriculum_id uuid NOT NULL,
  academic_year_id uuid NOT NULL,
  stage_id uuid NOT NULL,
  grade_id uuid NOT NULL,
  track_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, grade_id, curriculum_id),
  FOREIGN KEY (grade_id, curriculum_id, academic_year_id, stage_id)
    REFERENCES public.grades(id, curriculum_id, academic_year_id, stage_id)
    ON DELETE CASCADE
);

CREATE TABLE public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  curriculum_id uuid NOT NULL,
  academic_year_id uuid NOT NULL,
  stage_id uuid NOT NULL,
  grade_id uuid NOT NULL,
  track_id uuid NOT NULL,
  subject_code text,
  display_name text NOT NULL,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(name_i18n) = 'object'),
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(description_i18n) = 'object'),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, track_id, grade_id, curriculum_id),
  FOREIGN KEY (track_id, grade_id, curriculum_id)
    REFERENCES public.tracks(id, grade_id, curriculum_id) ON DELETE CASCADE
);

CREATE TABLE public.curriculum_offerings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  country_id uuid NOT NULL,
  educational_system_id uuid NOT NULL,
  curriculum_id uuid NOT NULL,
  academic_year_id uuid NOT NULL,
  stage_id uuid NOT NULL,
  grade_id uuid NOT NULL,
  track_id uuid NOT NULL,
  offering_code text,
  display_name text NOT NULL,
  publication_state text NOT NULL DEFAULT 'draft'
    CHECK (publication_state IN
      ('draft', 'under_review', 'approved', 'published', 'archived')),
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, tenant_id),
  UNIQUE (id, grade_id, curriculum_id, track_id),
  FOREIGN KEY (educational_system_id, country_id)
    REFERENCES public.educational_systems(id, country_id) ON DELETE RESTRICT,
  FOREIGN KEY (curriculum_id, educational_system_id, country_id)
    REFERENCES public.curricula(id, educational_system_id, country_id)
    ON DELETE RESTRICT,
  FOREIGN KEY (academic_year_id, curriculum_id)
    REFERENCES public.academic_years(id, curriculum_id) ON DELETE RESTRICT,
  FOREIGN KEY (stage_id, curriculum_id, academic_year_id)
    REFERENCES public.stages(id, curriculum_id, academic_year_id)
    ON DELETE RESTRICT,
  FOREIGN KEY (grade_id, curriculum_id, academic_year_id, stage_id)
    REFERENCES public.grades(id, curriculum_id, academic_year_id, stage_id)
    ON DELETE RESTRICT,
  FOREIGN KEY (track_id, grade_id, curriculum_id)
    REFERENCES public.tracks(id, grade_id, curriculum_id) ON DELETE RESTRICT
);

CREATE INDEX curriculum_offerings_context_idx
  ON public.curriculum_offerings
    (country_id, educational_system_id, grade_id, academic_year_id, track_id)
  WHERE is_active = true AND publication_state = 'published';

DO $$
DECLARE
  table_name text;
BEGIN
  FOREACH table_name IN ARRAY ARRAY[
    'languages', 'currencies', 'countries', 'regions', 'tenants', 'users',
    'roles', 'tenant_memberships', 'educational_systems', 'curricula',
    'academic_years', 'stages', 'grades', 'tracks', 'subjects',
    'curriculum_offerings'
  ] LOOP
    EXECUTE format(
      'CREATE TRIGGER %I BEFORE UPDATE ON public.%I
       FOR EACH ROW EXECUTE FUNCTION app_private.touch_updated_at()',
      table_name || '_touch_updated_at',
      table_name
    );
  END LOOP;
END;
$$;

COMMIT;