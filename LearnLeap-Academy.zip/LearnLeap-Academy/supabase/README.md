# Shatir Supabase foundation

This directory contains the schema source of truth for Shatir's Supabase PostgreSQL database.

## Scope

The migrations establish multi-tenant primitives, dynamic global catalogs, the country-to-grade curriculum hierarchy, learning content and assessments, student progress, achievements, subscriptions, payments, reports, admin roles, content versions, and row-level security.

Migrations create schema only. They do not insert countries, regions, education systems, academic years, stages, grades, tracks, subjects, languages, currencies, prices, roles, or demo content. Those records are data managed by the platform owner, not local constants.

## Apply

1. Create or select the intended Supabase project.
2. Open that project's SQL Editor.
3. Run the files in `migrations/` in lexicographic order, one file at a time.
4. Verify the resulting tables and RLS policies in Supabase before adding client code.

The live project was not changed as part of this workspace build: `SUPABASE_DB_URL` was not provided. Do not use the Replit-managed `DATABASE_URL` as a substitute. If automated application is enabled later, store the Supabase connection string only as the `SUPABASE_DB_URL` Replit secret.

## Security model

- The `public.users` row is a profile keyed to Supabase Auth's `auth.users` UUID. Authentication itself is a later roadmap module.
- Student learning contexts point to a specific curriculum offering. Learning-content RLS requires an active offering selected for that student, and content lookups should also filter by country, educational system, and grade.
- Answer keys are stored separately from question options and are not granted to ordinary authenticated clients.
- Progress, attempts, subscriptions, and payments are private to the learner/guardian or authorized tenant/platform admins.
- No service-role key belongs in a mobile or browser client.
- Platform and tenant roles are records, not seed constants. Add the first platform administrator through the Supabase SQL Editor only after the owner has created an Auth user and reviewed the account UUID. RLS requires the `platform.manage` permission for platform admins and `tenant.manage` for tenant admins.
- `platform_parameters` is for public configuration only; never store credentials or secrets in it.

## Bootstrap the first platform owner

Only do this in the intended Supabase project after creating the owner's Supabase Auth account and verifying its UUID in the dashboard. Replace the two values before running; the placeholder UUID deliberately raises an error. This is a manual bootstrap, not seeded migration data.

```sql
DO $bootstrap$
DECLARE
  owner_auth_user_id uuid := '00000000-0000-0000-0000-000000000000';
  owner_display_name text := 'REPLACE WITH OWNER DISPLAY NAME';
  owner_role_id uuid;
  platform_permission_id uuid;
BEGIN
  IF owner_auth_user_id = '00000000-0000-0000-0000-000000000000' THEN
    RAISE EXCEPTION 'Replace owner_auth_user_id with the verified Auth UUID first';
  END IF;

  INSERT INTO public.users (id, display_name)
  VALUES (owner_auth_user_id, owner_display_name)
  ON CONFLICT (id) DO UPDATE SET display_name = EXCLUDED.display_name;

  INSERT INTO public.permissions (permission_key, display_name)
  VALUES ('platform.manage', 'Manage platform')
  ON CONFLICT (permission_key) DO UPDATE SET display_name = EXCLUDED.display_name
  RETURNING id INTO platform_permission_id;

  IF platform_permission_id IS NULL THEN
    SELECT id INTO platform_permission_id
    FROM public.permissions
    WHERE permission_key = 'platform.manage';
  END IF;

  INSERT INTO public.roles (tenant_id, role_key, display_name, role_scope)
  VALUES (NULL, 'platform_owner', 'Platform owner', 'platform')
  ON CONFLICT (role_key) WHERE tenant_id IS NULL
  DO UPDATE SET is_active = true
  RETURNING id INTO owner_role_id;

  INSERT INTO public.role_permissions (role_id, permission_id)
  VALUES (owner_role_id, platform_permission_id)
  ON CONFLICT DO NOTHING;

  INSERT INTO public.admins (user_id, tenant_id, role_id, is_active)
  VALUES (owner_auth_user_id, NULL, owner_role_id, true)
  ON CONFLICT (user_id, role_id) WHERE tenant_id IS NULL
  DO UPDATE SET is_active = true;
END;
$bootstrap$;
```

## Migration order

- `202610020001_platform_taxonomy.sql` — tenants, users, roles, dynamic catalogs, and curriculum taxonomy.
- `202610020002_learning_and_operations.sql` — student contexts, lessons, assessments, progress, pricing, subscriptions, payments, reports, and versions.
- `202610020003_row_level_security.sql` — access helpers, indexes, grants, and RLS policies.
- `202610020004_auth_profiles.sql` — create a `public.users` profile when Supabase Auth creates an account.